INSERT INTO User_account(FirstName, LastName, BirthDate, Height, Weight, Sex) VALUES ('V�rady','L�szl�', '1993-12-18', 180, 60, true);
INSERT INTO Meal(MealTime, MealContent, Fullness) VALUES ('09:00', 'Pacal p�rk�tt', 10);
INSERT INTO Feel(FeelValue) VALUES ('Kipihent');
INSERT INTO Type(TypeID, TypeValue) VALUES (1, 'Fut�s');
INSERT INTO Day(DateID,Tempreature, FrontImpact, Humidity, Rain) VALUES ('2015-10-08', 15, 'Hidegfront, f�j a l�bujjam.', 50, true );
INSERT INTO Sport(Length, Type, Exhaustion) VALUES (60, 1, 7);
INSERT INTO Rating(Relaxed, Feel) VALUES (8, 1);
INSERT INTO Sleep(UserID, StartTime, EndTime, RatingID, MealID, SportID, DateOfDay) VALUES (1,'11:30','18:30', 1,1,1,'2015-10-08');





