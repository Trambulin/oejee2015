CREATE USER sas_user;
ALTER USER sas_user PASSWORD 'makdaralo';
GRANT sas_role TO sas_user;