DROP ROLE sas_user;
