DROP ROLE sas_role;
